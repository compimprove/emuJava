/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jBillu
 */

public class Account {
    
    private String traceFile;
    
    private int balance;
    
    public Account() {
    } //END Account() CONSTRUCTOR
    
    public Account( String tf ) {
        traceFile = tf;
    } //END Account() CONSTRUCTOR
    
    public void deposit( int amount ) {
    } //END depost() CONSTRUCTOR

    public int withdraw( int amount ) {
        return 0;
    } //END withdraw() METHOD

    public int closeAccount() {
        return 0;
    } //END closeAccount() METHOD

    public int openAccount( int amount ) {
        return 0;
    } //END openAccount() METHOD

} //EDN Account CLASS